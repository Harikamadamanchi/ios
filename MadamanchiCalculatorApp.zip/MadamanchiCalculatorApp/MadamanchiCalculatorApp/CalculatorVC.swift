//
//  ViewController.swift
//  MadamanchiCalculatorApp
//
//  Created by Madamanchi,Harika on 2/11/23.
//

import UIKit

class CalculatorVC : UIViewController {
    
    var Expression = ""
    
    override func viewDidLoad () {
        super.viewDidLoad ()
        // Do any additional setup after loading the view.
        mathExpressionLBL.text = ""
        mathExpressionLBL.numberOfLines = 0
    }
    
    @IBOutlet weak var mathExpressionLBL: UILabel!
    
    @IBAction func clearExpression(_ sender: UIButton) {
    }
    
    @IBAction func backspace(_ sender: UIButton) {
        guard !Expression.isEmpty else { return }
        Expression.removeLast()
        mathExpressionLBL.text = Expression
    }
    
    @IBAction func flipsign(_ sender: UIButton) {
        guard let flipsigncalculator = Double(Expression) else { return }
        let result8 = flipsigncalculator * -1
        mathExpressionLBL.text = " \(result8) "
    }
    
    @IBAction func percent(_ sender: UIButton) {
        guard let percentCalculator = Double(Expression) else { return }
        let result7 = percentCalculator / 100
        mathExpressionLBL.text = " \(result7) "
    }
    
    @IBAction func naturalLog(_ sender: UIButton) {
        guard let naturalLogCalculator = Double(Expression) else { return }
        let result6 = log(naturalLogCalculator)
        mathExpressionLBL.text = " \(result6) "
    }
    
    var n : Double = 0
    @IBAction func factorial(_ sender: UIButton)  {
        func factorial(_n: Double) -> Double {
        guard n >= 0 && n.truncatingRemainder(dividingBy: 1) == 0 else{
            return Double.nan
            }
        var result : Double = 1
        if n == 0 {
            return result
        }
        for i in 1...Int(n){
            result *= Double(i)
            if result.isInfinite{
                return Double.nan
            }
        }
        return result
    }
    }
    
    @IBAction func tenpow(_ sender: UIButton) {
        guard let tenpower = Double(Expression) else { return }
        let result1 = pow(10,tenpower)
        mathExpressionLBL.text = " \(result1) "
    }
    
    @IBAction func calcSin(_ sender: UIButton) {
        guard let calculatingSin = Double(Expression) else { return }
        let result2 = sin(calculatingSin)
        mathExpressionLBL.text = " \(result2) "
    }
    
    @IBAction func calCos(_ sender: UIButton) {
        guard let calculatingCos = Double(Expression) else { return }
        let result3 = sin(calculatingCos)
        mathExpressionLBL.text = " \(result3) "
    }
    
    @IBAction func calcTan(_ sender: UIButton) {
        guard let calculatingTan = Double(Expression) else { return }
        let result4 = sin(calculatingTan)
        mathExpressionLBL.text = " \(result4) "
    }
    
    @IBAction func inverse(_ sender: UIButton) {
        guard let inverseCalculating = Double(Expression) else { return }
        let result5 = 1 / inverseCalculating
        mathExpressionLBL.text = " \(result5) "
    }
    
    @IBAction func result(_ sender: UIButton) {
        let expression = NSExpression(format: Expression)
            if let result = expression.expressionValue(with: nil, context: nil) as? Int {
                Expression = "\(result)"
                mathExpressionLBL.text = Expression
            } else {
                Expression = "Error"
                mathExpressionLBL.text = Expression
        }
    
        @IBAction func tappedChar(_ sender: UIButton) {
        guard let char =  sender.titleLabel?.text  else {
             return
        }
        if Expression == "Error"{
            Expression = ""
        }
        Expression += char
        mathExpressionLBL.text = Expression
            
            
    }
    
    
    
}
}
