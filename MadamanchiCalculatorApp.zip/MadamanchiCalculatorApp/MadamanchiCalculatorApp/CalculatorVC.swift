//
//  ViewController.swift
//  MadamanchiCalculatorApp
//
//  Created by Madamanchi,Harika on 2/11/23.
//

import UIKit

class CalculatorVC : UIViewController {
    
    var Expression = ""
    
    override func viewDidLoad () {
        super.viewDidLoad ()
        // Do any additional setup after loading the view.
        mathExpressionLBL.text = ""
        mathExpressionLBL.numberOfLines = 0
    }
    
    @IBOutlet weak var mathExpressionLBL: UILabel!
    
    @IBAction func clearExpression(_ sender: UIButton) {
    }
    
    @IBAction func backspace(_ sender: UIButton) {
        guard !Expression.isEmpty else { return }
        Expression.removeLast()
        mathExpressionLBL.text = Expression
    }
    
    @IBAction func flipsign(_ sender: UIButton) {
        guard let flipsigncalculator = Double(Expression) else { return }
        let result8 = flipsigncalculator * -1
        mathExpressionLBL.text = " \(result8) "
    }
    
    @IBAction func percent(_ sender: UIButton) {
        guard let percentCalculator = Double(Expression) else { return }
        let result7 = percentCalculator / 100
        mathExpressionLBL.text = " \(result7) "
    }
    
    @IBAction func naturalLog(_ sender: UIButton) {
        guard let naturalLogCalculator = Double(Expression) else { return }
        let result6 = log(naturalLogCalculator)
        mathExpressionLBL.text = " \(result6) "
    }
    
    var num : Int
    @IBAction func factorial(_ sender: UIButton) {
        guard num >= 0 else
        {
            return
        }
        var result = 1
        for i in 1...num {
            result = result * i
        }
        mathExpressionLBL.text = " \(result) "
    }
    
    
    @IBAction func tenpow(_ sender: UIButton) {
        guard let tenpower = Double(Expression) else { return }
        let result1 = pow(10,tenpower)
        mathExpressionLBL.text = " \(result1) "
    }
    
    @IBAction func calcSin(_ sender: UIButton) {
        guard let calculatingSin = Double(Expression) else { return }
        let result2 = sin(calculatingSin)
        mathExpressionLBL.text = " \(result2) "
    }
    
    @IBAction func calCos(_ sender: UIButton) {
        guard let calculatingCos = Double(Expression) else { return }
        let result3 = sin(calculatingCos)
        mathExpressionLBL.text = " \(result3) "
    }
    
    @IBAction func calcTan(_ sender: UIButton) {
        guard let calculatingTan = Double(Expression) else { return }
        let result4 = sin(calculatingTan)
        mathExpressionLBL.text = " \(result4) "
    }
    
    @IBAction func inverse(_ sender: UIButton) {
        guard let inverseCalculating = Double(Expression) else { return }
        let result5 = 1 / inverseCalculating
        mathExpressionLBL.text = " \(result5) "
    }
    
    @IBAction func result(_ sender: UIButton) {
        }
    
    @IBAction func tappedChar(_ sender: UIButton) {
        Expression += sender.titleLabel?.text ?? ""
        mathExpressionLBL.text = Expression
    }
    
    
    
}

