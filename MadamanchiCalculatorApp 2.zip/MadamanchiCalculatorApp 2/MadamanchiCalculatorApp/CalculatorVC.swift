//
//  ViewController.swift
//  MadamanchiCalculatorApp
//
//  Created by Madamanchi,Harika on 2/11/23.
//

import UIKit
import MathExpression

class CalculatorVC : UIViewController {
    
    var Expression = ""
    
    override func viewDidLoad () {
        super.viewDidLoad ()
        // Do any additional setup after loading the view.
        mathExpressionLBL.text = "0"
        mathExpressionLBL.numberOfLines = 0
    }
    
    @IBOutlet weak var mathExpressionLBL: UILabel!
    
    @IBAction func clearExpression(_ sender: UIButton) {
        
        self.mathExpressionLBL.text! = "0"
        
    }
    
    @IBAction func backspace(_ sender: UIButton) {
        guard !Expression.isEmpty else { return }
        Expression.removeLast()
        mathExpressionLBL.text = Expression
    }
    
    @IBAction func flipsign(_ sender: UIButton) {
        
        
        guard let text = self.mathExpressionLBL, let value = text.text else {
            return
        }
        
        
        var x = evaluate(exp: value)
        if(x != 0) {
            x = -x
        } else {
            x = 0
        }
        self.mathExpressionLBL.text = isInteger(number: x) ? "\(Int(x))" : "\(x)"
    }
    
    @IBAction func percent(_ sender: UIButton) {
        let temp = self.evaluate(exp: self.mathExpressionLBL.text!+"/100")
        
        self.mathExpressionLBL.text! = String(temp)
    }
    
    @IBAction func naturalLog(_ sender: UIButton) {
        let temp = self.evaluate(exp: self.mathExpressionLBL.text!)
        
        let result = Double(temp)
        
        self.mathExpressionLBL.text! = String(log(result))
    }
    
    
    @IBAction func factorial(_ sender: UIButton)  {
        guard let text = self.mathExpressionLBL, let value = text.text else {
            return
        }
        
        var fact : Double = 1
    var x: Double = evaluate(exp: value)
        while(x >= 1) {
            fact = fact * x
            x = x - 1
        }
        if (x == 0)
        {
            self.mathExpressionLBL.text! = "0"
        }
        self.mathExpressionLBL.text = isInteger(number: fact) ? "\(Int(fact))" : "\(fact)"
    }
    
    @IBAction func tenpow(_ sender: UIButton) {
        let val = self.evaluate(exp: self.mathExpressionLBL.text!)
        
        let temp = Double(val)
        
        
        self.mathExpressionLBL.text! = String(pow(10,temp))
    }
    
    @IBAction func calcSin(_ sender: UIButton) {
        guard let text = self.mathExpressionLBL, let value = text.text else {
            return
        }
        
        let temp = sin(evaluate(exp: value))
        self.mathExpressionLBL.text = isInteger(number: temp) ? "\(Int(temp))" : "\(temp)"
    }
    
    @IBAction func calCos(_ sender: UIButton) {
        guard let text = self.mathExpressionLBL, let value = text.text else {
            return
        }
        
        let temp = cos(evaluate(exp: value))
        self.mathExpressionLBL.text = isInteger(number: temp) ? "\(Int(temp))" : "\(temp)"
    }
    
    @IBAction func calcTan(_ sender: UIButton) {
        guard let text = self.mathExpressionLBL, let value = text.text else {
            return
        }
        
        let tanResult = tan(evaluate(exp: value))
        self.mathExpressionLBL.text = isInteger(number: tanResult) ? "\(Int(tanResult))" : "\(tanResult)"
    }
    
    @IBAction func inverse(_ sender: UIButton) {
        let expVal = self.evaluate(exp: self.mathExpressionLBL.text!)
        let result = Double(expVal)
        self.mathExpressionLBL.text! = String((1/result))
        
    }
    
    @IBAction func result(_ sender: UIButton) {
        let temp = self.evaluate(exp: self.mathExpressionLBL.text!)
                            
                self.mathExpressionLBL.text = isInteger(number: temp) ? "\(Int(temp))" : "\(temp)"
}
    
    @IBAction func tappedChar(_ sender: UIButton) {
        
        guard let btnTitle = sender.titleLabel?.text else {
                    
                    return
                }
        
        
        
        if btnTitle == "−" || btnTitle == "+" {
                    
                    let expVal = self.evaluate(exp: self.mathExpressionLBL.text!)
                    
            self.mathExpressionLBL.text = isInteger(number: expVal) ? "\(Int(expVal))" : "\(expVal)"
                    
                    self.mathExpressionLBL.text! += btnTitle == "−" ? "-" : "+"
                    
        }
        else if
            btnTitle == "×" || btnTitle == "÷" {
                        
                        let expVal = self.evaluate(exp: self.mathExpressionLBL.text!)
                        
            self.mathExpressionLBL.text = isInteger(number: expVal) ? "\(Int(expVal))" : "\(expVal)"
                        
                        self.mathExpressionLBL.text! += btnTitle == "÷" ? "/" : "*"
                        
            }
        
        else{
                    
                    self.mathExpressionLBL.text! += btnTitle
                }
        
    }
    
    private func evaluate(exp: String) -> Double {
        do {
            let mathExp = try MathExpression(exp)
            
            return mathExp.evaluate()
        } catch {
            print("Invalid Expression")
        }
        return 0.0
    }
    
    
    private func isInteger(number : Double) -> Bool {
        number.truncatingRemainder(dividingBy: 1.0).isZero
    }
}
